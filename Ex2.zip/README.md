# Computer Graphics Course
## Homework Exercise 2

### Danit Noa Yechezkel (203964036)
### Dekel Menashe (311224117)
### Keren Halpert (313604621)

To start the program, open the HTML file in an internet browser.